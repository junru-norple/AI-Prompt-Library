<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Clip Corners Button

## 繁體中文

- Entry ID: `smooth-ui-oss:4a949ed6c66d582c`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/clip-corners-button/index.tsx`
- 來源 SHA-256：`1fbe51a8d83e82303f9778092d46a5bf82031b0a44d6444fb4da93f11ac3b6cd`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

