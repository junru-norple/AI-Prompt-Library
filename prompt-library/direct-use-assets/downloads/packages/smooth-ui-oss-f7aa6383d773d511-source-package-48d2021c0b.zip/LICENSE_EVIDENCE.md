<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: SmoothUI
- Repository: https://github.com/educlopez/smoothui
- Commit: 0a4120bb41b4d85ac796c7885552de6d0a5d7308
- Source path: references/community/smooth-ui-oss/packages/smoothui/components/shader-reveal-circle-transition/index.tsx
- 原作者 / Original creator: 上游未提供個別作者／Individual creator not supplied by upstream
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: SmoothUI maintainers
- Entry license: MIT
- License status: verified
- Evidence path: LICENSE, packages/cli/LICENSE

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
