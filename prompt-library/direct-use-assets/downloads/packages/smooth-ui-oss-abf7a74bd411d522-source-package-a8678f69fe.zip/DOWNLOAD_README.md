<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Bottom UP Letters

## 繁體中文

- Entry ID: `smooth-ui-oss:abf7a74bd411d522`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/bottom-up-letters/index.tsx`
- 來源 SHA-256：`94913f8de08df9d6c1b317ee4fe366935d4c787dfc43bad50e617d0010024c4a`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

