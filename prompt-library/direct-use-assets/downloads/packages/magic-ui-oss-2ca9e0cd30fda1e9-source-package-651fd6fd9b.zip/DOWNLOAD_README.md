<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Ripple

## 繁體中文

- Entry ID: `magic-ui-oss:2ca9e0cd30fda1e9`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/ripple.tsx`
- 來源 SHA-256：`1ac207017c0f4e993f83a1ead8b8a1b4a92286ef1595a297aba79782b2616eaf`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

