<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# G2 Design System UI Kit（設計系統套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:g2-design-system-ui-kit-mqgbmh2w-768fb5bb`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/community/g2-design-system-ui-kit-mqgbmh2w/index.html`
- 來源 SHA-256：`00a40c0c5107872d69dcc0995a18fbaaf65cb4a22016bca89c4a65f20a931008`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

