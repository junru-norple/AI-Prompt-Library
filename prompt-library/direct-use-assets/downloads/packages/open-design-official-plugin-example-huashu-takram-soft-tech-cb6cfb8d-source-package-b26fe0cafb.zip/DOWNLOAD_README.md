<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像企业销售负责人一样写买方委员会转发稿（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-huashu-takram-soft-tech-cb6cfb8d`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/huashu-takram-soft-tech/example.html`
- 來源 SHA-256：`d142dac1bf9fa0df92d46a9b9429db4b907e8ed9de6f5d00dd25a7de2d7cc886`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

