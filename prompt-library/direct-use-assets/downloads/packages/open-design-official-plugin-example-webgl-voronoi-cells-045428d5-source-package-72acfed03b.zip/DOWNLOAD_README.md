<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Voronoi 細胞（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-webgl-voronoi-cells-045428d5`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/webgl-voronoi-cells/example.html`
- 來源 SHA-256：`30cc2c76e1fe259e92c1dea8c499cb758ab10d37a3c356843eccbf9c40dd7db1`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

