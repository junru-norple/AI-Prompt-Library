<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 授權範圍 / License scope

## 繁體中文

- `package/**/*.html|css|js|ts|tsx|jsx` 的原創程式碼：MIT。
- `package/**/PROMPT.md`、README 與原創文字／設計內容：CC BY 4.0。
- 上述授權僅涵蓋 `junru-norple` 實際持有著作權或相關權利的部分。
- 第三方依賴只被宣告、沒有封裝，仍依各自條款；商標與品牌權利不在授權範圍內。

## English

- Original code under `package/**/*.html|css|js|ts|tsx|jsx`: MIT.
- `package/**/PROMPT.md`, README copy, and original textual/design content: CC BY 4.0.
- These grants apply only to the extent copyright or related rights are held by `junru-norple`.
- Third-party dependencies are declared but not bundled and remain under their own terms; trademark and brand rights are not granted.
