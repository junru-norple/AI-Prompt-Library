<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 第三方聲明 / Third-party notices

## 繁體中文

GSAP 若被宣告，分類為 GreenSock Standard No-Charge License（不是 MIT），且未封裝。Lenis、Three.js、Motion、Next.js、React 與 React DOM 依各自 MIT License；TypeScript 依 Apache-2.0；這些相依套件均未封裝。所有第三方名稱與商標歸其權利人所有；本套件不表示其背書、合作或隸屬關係。

## English

When declared, GSAP is classified under the GreenSock Standard No-Charge License (not MIT) and is not bundled. Lenis, Three.js, Motion, Next.js, React, and React DOM use their respective MIT licenses; TypeScript uses Apache-2.0; none of these dependencies is bundled. All third-party names and marks belong to their owners; no endorsement, partnership, or affiliation is implied.
