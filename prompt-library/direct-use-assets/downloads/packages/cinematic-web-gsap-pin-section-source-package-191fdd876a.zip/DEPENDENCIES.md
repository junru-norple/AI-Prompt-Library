<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

## 繁體中文

以下套件只由來源專案宣告，未封裝於本 ZIP：
- gsap@3.15.0

## English

The following packages are declared by the source project and are not bundled in this ZIP:
- gsap@3.15.0
