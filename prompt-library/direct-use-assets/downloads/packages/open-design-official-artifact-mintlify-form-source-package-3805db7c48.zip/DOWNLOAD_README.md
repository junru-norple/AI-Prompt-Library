<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# mintlify 設計系統成果：form

## 繁體中文

- Entry ID: `open-design-official:artifact:mintlify:form`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/mintlify/system/artifacts/form.html`
- 來源 SHA-256：`34407576f1e9110d171d916cde006feca706b64e7ea11c41925bc96c1a74c532`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

