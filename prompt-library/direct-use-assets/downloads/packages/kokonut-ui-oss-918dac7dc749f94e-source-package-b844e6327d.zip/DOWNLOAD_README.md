<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Card Flip

## 繁體中文

- Entry ID: `kokonut-ui-oss:918dac7dc749f94e`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/card-flip.tsx`
- 來源 SHA-256：`7a0b754dceb7a4d7275f643c1326ebbec8225e2e42f69c9f5a9286cbb8d46c3c`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

