<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像能让 CFO 读懂的分析负责人一样写 KPI 决策简报（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-hps-y2k-chrome-756d1a48`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/hps-y2k-chrome/example.html`
- 來源 SHA-256：`1266e27012949925db66fa242fcd5aff85f138df387d5a9d12762132f94451e6`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

