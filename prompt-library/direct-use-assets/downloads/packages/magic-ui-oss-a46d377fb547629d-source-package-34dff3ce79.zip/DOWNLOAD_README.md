<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · File Tree

## 繁體中文

- Entry ID: `magic-ui-oss:a46d377fb547629d`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/file-tree.tsx`
- 來源 SHA-256：`ffc123a907fa76f9bcc4a2bc42fab53473021343399f91e9954e3923b0f07416`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

