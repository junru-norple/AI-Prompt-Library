<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

繁體中文：此來源 Artifact 沒有記錄外部依賴。

English: No external dependency is recorded for this source artifact.
