<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 授權範圍 / License scope

繁體中文：`source/` 內的上游來源依 `Apache-2.0`；權利歸上游權利人。本 ZIP 的清單與說明文字僅在本專案持有權利的範圍內依 CC BY 4.0 提供。

English: Upstream material under `source/` remains under `Apache-2.0` and belongs to its upstream rights holders. Package manifests and explanatory prose are CC BY 4.0 only to the extent this project holds those rights.
