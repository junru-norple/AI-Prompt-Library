<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# xiaohongshu 設計系統成果：email

## 繁體中文

- Entry ID: `open-design-official:artifact:xiaohongshu:email`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/xiaohongshu/system/artifacts/email.html`
- 來源 SHA-256：`8521f71ddf7b98d7cbff834ee972173865b57404c33e221aa62b9e11b25ba764`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

