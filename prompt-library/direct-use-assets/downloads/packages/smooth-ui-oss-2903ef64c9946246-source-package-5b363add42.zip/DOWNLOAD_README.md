<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · AI Context Meter

## 繁體中文

- Entry ID: `smooth-ui-oss:2903ef64c9946246`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/ai-context-meter/index.tsx`
- 來源 SHA-256：`bd6e99d5e889600d268347ebcb54ac5db241d9f066fda59e1e18dae162a50ee8`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

