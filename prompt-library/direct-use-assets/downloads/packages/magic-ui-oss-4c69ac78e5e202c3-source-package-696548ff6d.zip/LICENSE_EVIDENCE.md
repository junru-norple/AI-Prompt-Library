<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: Magic UI
- Repository: https://github.com/magicuidesign/magicui
- Commit: 0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25
- Source path: references/community/magic-ui-oss/apps/www/registry/magicui/meteors.tsx
- 原作者 / Original creator: 上游未提供個別作者／Individual creator not supplied by upstream
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: Magic UI maintainers
- Entry license: MIT
- License status: verified
- Evidence path: LICENSE.md

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
