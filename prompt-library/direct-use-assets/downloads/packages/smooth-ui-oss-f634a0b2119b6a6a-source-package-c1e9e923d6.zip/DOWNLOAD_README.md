<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Pagination

## 繁體中文

- Entry ID: `smooth-ui-oss:f634a0b2119b6a6a`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/pagination/index.tsx`
- 來源 SHA-256：`b4cfbdd40177193d2f12eb433eaf31ddc52219ff8763b4770462092bfdf567a7`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

