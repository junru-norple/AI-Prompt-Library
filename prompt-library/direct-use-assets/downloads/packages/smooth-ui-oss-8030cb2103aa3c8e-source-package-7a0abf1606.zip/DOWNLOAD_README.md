<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Shader Reveal Stripes Transition

## 繁體中文

- Entry ID: `smooth-ui-oss:8030cb2103aa3c8e`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/shader-reveal-stripes-transition/index.tsx`
- 來源 SHA-256：`0d0be39ef9297ec237e86ffb5fc7e147d1a24dc6fdfbeebe6ed4a018eaf29521`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

