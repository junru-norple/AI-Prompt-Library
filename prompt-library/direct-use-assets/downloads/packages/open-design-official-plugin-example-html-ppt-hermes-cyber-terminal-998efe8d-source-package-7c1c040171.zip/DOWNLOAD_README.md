<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像应用 AI 工程师一样讲 BYOK 选型（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-hermes-cyber-terminal-998efe8d`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-hermes-cyber-terminal/example.html`
- 來源 SHA-256：`5a20603cf76bf8bb650d4efc9fa4b12e57ef666760816b0b76ad70cf72b0b2b5`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

