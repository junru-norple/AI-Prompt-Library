<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · AI Diff

## 繁體中文

- Entry ID: `smooth-ui-oss:3c6d7974ef61556f`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/ai-diff/index.tsx`
- 來源 SHA-256：`00964def46ab0636048ce6447d70a14514356d2720d41d55398d7e0d0a2f77f6`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

