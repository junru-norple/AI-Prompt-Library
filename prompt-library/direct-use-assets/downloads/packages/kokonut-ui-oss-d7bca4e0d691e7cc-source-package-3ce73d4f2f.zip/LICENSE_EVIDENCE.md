<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: Kokonut UI Open Source Components
- Repository: https://github.com/kokonut-labs/kokonutui
- Commit: 13f3d666c008a868ef2b9af371e6c6003fe4ee80
- Source path: references/community/kokonut-ui-oss/components/kokonutui/scroll-text.tsx
- 原作者 / Original creator: 上游未提供個別作者／Individual creator not supplied by upstream
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: Kokonut Labs
- Entry license: MIT
- License status: verified
- Evidence path: LICENSE

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
