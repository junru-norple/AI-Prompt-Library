<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Currency Transfer

## 繁體中文

- Entry ID: `kokonut-ui-oss:353d1372160bef84`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/currency-transfer.tsx`
- 來源 SHA-256：`e7af91ff37ff0ffd38aed9b06609e358ff831989790808051571025bd28e19c7`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

