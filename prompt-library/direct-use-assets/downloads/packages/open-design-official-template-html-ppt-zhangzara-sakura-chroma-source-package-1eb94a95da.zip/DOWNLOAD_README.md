<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# html-ppt-zhangzara-sakura-chroma

## 繁體中文

- Entry ID: `open-design-official:template:html-ppt-zhangzara-sakura-chroma`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-templates/html-ppt-zhangzara-sakura-chroma/example.html`
- 來源 SHA-256：`4803581009572a19cde13055d52aa1fcf11387c3c012d1db429f5f8b10066a1c`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

