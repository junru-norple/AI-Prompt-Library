<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · FAQ 2

## 繁體中文

- Entry ID: `smooth-ui-oss:66085ae52c46e9fb`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/blocks/faqs/faq-2/index.tsx`
- 來源 SHA-256：`7c927a670f6d16ac3fbe7e69c20d8b911f0cc9ce0a2ac961b6081d4f1d4784f4`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

