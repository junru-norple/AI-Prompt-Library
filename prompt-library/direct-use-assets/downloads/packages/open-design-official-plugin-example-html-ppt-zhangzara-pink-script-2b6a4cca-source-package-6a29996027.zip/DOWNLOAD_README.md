<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像婚礼讲述者一样把纪念日做成影像散文（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-zhangzara-pink-script-2b6a4cca`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-zhangzara-pink-script/example.html`
- 來源 SHA-256：`667d15a3c070cde89ed2ffe6c4111e53860339a5ef9f5419223413dd7afde3dc`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

