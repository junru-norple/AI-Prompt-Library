<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · AI Approval

## 繁體中文

- Entry ID: `smooth-ui-oss:8c7263423076d63e`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/ai-approval/index.tsx`
- 來源 SHA-256：`8f33c5c35b86bfff442b2c9d928992114016c46714a62e361b7527af0d157618`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

