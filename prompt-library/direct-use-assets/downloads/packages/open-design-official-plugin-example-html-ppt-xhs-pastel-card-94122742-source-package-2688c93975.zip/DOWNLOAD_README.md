<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像叙事播客制作人一样写个人宣言演讲（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-xhs-pastel-card-94122742`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-xhs-pastel-card/example.html`
- 來源 SHA-256：`801959281614f127edb14b13bfaf0565b971f914bfd2d1dbe6417a6c9b2aedde`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

