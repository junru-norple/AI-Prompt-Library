<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Number Ticker

## 繁體中文

- Entry ID: `magic-ui-oss:f6b4a5f5d4888023`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/number-ticker.tsx`
- 來源 SHA-256：`0f7dcbc6a1962615a877590304e846f33d390002a51f2226f544938577c220f4`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

