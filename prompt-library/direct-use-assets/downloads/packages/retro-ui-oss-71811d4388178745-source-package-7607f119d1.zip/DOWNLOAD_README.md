<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Retro UI / NeoBrutalism · input-style-error

## 繁體中文

- Entry ID: `retro-ui-oss:71811d4388178745`
- Artifact kind: `source-package`
- 固定來源：`retro-ui-oss` @ `d5fbc0e823bb66575f5372c3df03ee43be45c91b`
- 來源檔案：`references/community/retro-ui-oss/components/retroui/Input.tsx`
- 來源 SHA-256：`e08b918ad4733fd6b6499b4da1a0bb33640f4c51a067887170055a9b00baea0a`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

