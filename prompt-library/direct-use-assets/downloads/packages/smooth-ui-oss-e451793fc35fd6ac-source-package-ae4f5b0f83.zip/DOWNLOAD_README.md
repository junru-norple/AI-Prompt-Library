<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Short Slide Right

## 繁體中文

- Entry ID: `smooth-ui-oss:e451793fc35fd6ac`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/short-slide-right/index.tsx`
- 來源 SHA-256：`6eb31217712490f76c79a4aaca2606b235ed7dfa031bb7213bb26646e57ab403`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

