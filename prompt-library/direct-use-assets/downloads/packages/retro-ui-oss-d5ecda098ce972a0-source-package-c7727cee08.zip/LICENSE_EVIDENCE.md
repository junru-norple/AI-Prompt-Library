<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: Retro UI / NeoBrutalism
- Repository: https://github.com/neobrutalism/neobrutalism
- Commit: d5fbc0e823bb66575f5372c3df03ee43be45c91b
- Source path: references/community/retro-ui-oss/components/retroui/Label.tsx
- 原作者 / Original creator: 上游未提供個別作者／Individual creator not supplied by upstream
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: NeoBrutalism maintainers
- Entry license: MIT
- License status: verified
- Evidence path: LICENCE.md

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
