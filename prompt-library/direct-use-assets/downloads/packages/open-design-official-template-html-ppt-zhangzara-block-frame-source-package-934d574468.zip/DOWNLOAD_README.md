<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# html-ppt-zhangzara-block-frame

## 繁體中文

- Entry ID: `open-design-official:template:html-ppt-zhangzara-block-frame`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-templates/html-ppt-zhangzara-block-frame/example.html`
- 來源 SHA-256：`f9b13d866523b55fbac0d54b6f5410ed085478b6eb7d3de95d38455439190f7d`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

