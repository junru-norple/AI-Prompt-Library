<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- @repo/ai-approval@workspace:*
- @repo/ai-artifact@workspace:*
- @repo/ai-context-meter@workspace:*
- @repo/ai-conversation@workspace:*
- @repo/ai-core@workspace:*
- @repo/ai-diff@workspace:*
- @repo/ai-loader@workspace:*
- @repo/ai-message@workspace:*
- @repo/ai-prompt-input@workspace:*
- @repo/ai-reasoning@workspace:*
- @repo/ai-response@workspace:*
- @repo/ai-sources@workspace:*
- @repo/ai-suggestions@workspace:*
- @repo/ai-task-list@workspace:*
- @repo/ai-tool-call@workspace:*
- @repo/shadcn-ui@workspace:*
- @repo/siri-orb@workspace:*
- lucide-react@^0.545.0
- motion@^12.23.25
- react-dom@^19.2.0
- react@^19.2.0

The following packages are declared by the source project and are not bundled in this ZIP:
- @repo/ai-approval@workspace:*
- @repo/ai-artifact@workspace:*
- @repo/ai-context-meter@workspace:*
- @repo/ai-conversation@workspace:*
- @repo/ai-core@workspace:*
- @repo/ai-diff@workspace:*
- @repo/ai-loader@workspace:*
- @repo/ai-message@workspace:*
- @repo/ai-prompt-input@workspace:*
- @repo/ai-reasoning@workspace:*
- @repo/ai-response@workspace:*
- @repo/ai-sources@workspace:*
- @repo/ai-suggestions@workspace:*
- @repo/ai-task-list@workspace:*
- @repo/ai-tool-call@workspace:*
- @repo/shadcn-ui@workspace:*
- @repo/siri-orb@workspace:*
- lucide-react@^0.545.0
- motion@^12.23.25
- react-dom@^19.2.0
- react@^19.2.0
