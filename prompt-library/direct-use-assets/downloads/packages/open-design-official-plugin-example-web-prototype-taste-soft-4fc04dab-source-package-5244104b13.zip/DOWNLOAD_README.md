<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Web Prototype Taste Soft（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-web-prototype-taste-soft-4fc04dab`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/web-prototype-taste-soft/example.html`
- 來源 SHA-256：`8373070f696f171eb8c8f1d8830fa4cc29aea0711331411080217ad8f7e17945`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

