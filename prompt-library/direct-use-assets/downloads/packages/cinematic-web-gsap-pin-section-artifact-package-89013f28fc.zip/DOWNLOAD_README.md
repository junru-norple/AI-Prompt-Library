<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 軌道工坊捲動釘選敘事

## 繁體中文

- Entry ID: `cinematic-web:gsap-pin-section`
- Artifact kind: `artifact-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/gsap-pin-section/index.html`
- Source SHA-256: `540af966c9fbf0b5746d902c3f6067e1f363082d94c31d59d86e48dd74b6e717`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
