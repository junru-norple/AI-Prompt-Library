<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像主创品牌设计师一样发布视觉识别系统（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-zhangzara-creative-mode-a34af66d`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-zhangzara-creative-mode/example.html`
- 來源 SHA-256：`73b5c7a43d12e4c65ef8adf9ac82d3e71f2b5a045d1ad58c8de1b1361f25c318`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

