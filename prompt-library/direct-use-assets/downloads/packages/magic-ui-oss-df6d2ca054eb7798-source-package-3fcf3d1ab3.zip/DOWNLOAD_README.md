<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Animated Beam

## 繁體中文

- Entry ID: `magic-ui-oss:df6d2ca054eb7798`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/animated-beam.tsx`
- 來源 SHA-256：`6afa2ee1d01694a428eb8517d48deebe5c6b532dc0ee871800bb9d92aae43e79`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

