<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Pricing 2

## 繁體中文

- Entry ID: `smooth-ui-oss:493d296ed8c14123`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/blocks/pricing/pricing-2/index.tsx`
- 來源 SHA-256：`cef21ad3aab507be773ee086d7cf858e5256492431feacdd2e7805093877acc8`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

