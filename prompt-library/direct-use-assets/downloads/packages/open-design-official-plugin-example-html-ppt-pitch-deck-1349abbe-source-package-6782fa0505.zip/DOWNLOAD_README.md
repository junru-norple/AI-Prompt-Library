<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像顶级加速器合伙人一样写 Demo Day 路演（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-pitch-deck-1349abbe`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-pitch-deck/example.html`
- 來源 SHA-256：`6549b7cc5485dac2b68e57082c1fba428bb0f9f393c4d391a91c42af7f60ca3c`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

