<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像音乐节艺术总监一样讲海报系列案例（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-zhangzara-raw-grid-9082ce59`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-zhangzara-raw-grid/example.html`
- 來源 SHA-256：`11871b0f16e12f40fa5353fac9786b5d8f6623a30ff5e59c28c8aacc1cf2fc52`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

