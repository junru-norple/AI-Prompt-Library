<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像顶级导师一样答辩计算机毕业项目（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-fs-notebook-tabs-21149403`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/fs-notebook-tabs/example.html`
- 來源 SHA-256：`9b1049ff5113cfb1a3101b6e7d85337002d7925d7a479a4226069a0625279198`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

