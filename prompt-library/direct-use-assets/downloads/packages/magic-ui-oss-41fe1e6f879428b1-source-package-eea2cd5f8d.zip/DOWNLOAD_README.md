<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Ripple Button

## 繁體中文

- Entry ID: `magic-ui-oss:41fe1e6f879428b1`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/ripple-button.tsx`
- 來源 SHA-256：`828d7883953843761cb80fd6f59b6115e72d8db6bc83471e7ee8abf049ab6863`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

