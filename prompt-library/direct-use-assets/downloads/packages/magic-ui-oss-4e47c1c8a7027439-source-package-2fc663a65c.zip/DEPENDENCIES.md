<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- cobe@^0.6.4
- motion

The following packages are declared by the source project and are not bundled in this ZIP:
- cobe@^0.6.4
- motion
