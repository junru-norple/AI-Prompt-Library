<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Retro UI / NeoBrutalism · Base UI Toggle Group

## 繁體中文

- Entry ID: `retro-ui-oss:c67ffbb48c11d5db`
- Artifact kind: `source-package`
- 固定來源：`retro-ui-oss` @ `d5fbc0e823bb66575f5372c3df03ee43be45c91b`
- 來源檔案：`references/community/retro-ui-oss/components/retroui/ToggleGroup.tsx`
- 來源 SHA-256：`02fd5e4fa58ad20b70caa0a6df2a49c8849f4ed741724de144f89d57f8564472`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

