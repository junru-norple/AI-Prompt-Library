<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: Open Design Official Multi-Artifact Library
- Repository: https://github.com/nexu-io/open-design.git
- Commit: bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b
- Source path: references/community/open-design/plugins/_official/examples/hps-memphis-pop/example.html
- 原作者 / Original creator: lewislulu
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: nexu-io / Open Design maintainers
- 作者證據 / Creator evidence: plugins/_official/examples/hps-memphis-pop/open-design.json:20 (author.name; SHA-256 3ae095ea84806f03a1c5cb710be9fce089615af7ca07f33fb9350a955700ff27)
- Entry license: MIT
- License status: verified-item-declaration
- Evidence path: plugins/_official/examples/hps-memphis-pop/SKILL.md#source.license

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
