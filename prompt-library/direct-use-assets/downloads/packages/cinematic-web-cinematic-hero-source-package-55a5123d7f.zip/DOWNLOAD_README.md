<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 影院式星圖 Hero

## 繁體中文

- Entry ID: `cinematic-web:cinematic-hero`
- Artifact kind: `source-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/cinematic-hero/index.html`
- Source SHA-256: `2d2602acfb2b0e68982046e96f00ef748dec2b17d431f693e62758928f81f5af`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
