<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Highlighter

## 繁體中文

- Entry ID: `magic-ui-oss:cd76d9c45be54b1a`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/highlighter.tsx`
- 來源 SHA-256：`521c876ac04938ae747126a5277c14c6eb19114a9a09c3567249a7d2ee2af5b2`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

