<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Dock

## 繁體中文

- Entry ID: `magic-ui-oss:e7e532ea6d8b5852`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/dock.tsx`
- 來源 SHA-256：`c12d578d4a273036fa435b67d8374d6fe9c7bcb962665cefc7b851aa86d12441`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

