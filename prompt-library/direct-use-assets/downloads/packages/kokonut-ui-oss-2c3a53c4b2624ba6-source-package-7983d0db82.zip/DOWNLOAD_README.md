<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Shapes Hero

## 繁體中文

- Entry ID: `kokonut-ui-oss:2c3a53c4b2624ba6`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/shape-hero.tsx`
- 來源 SHA-256：`cd4b91156d779f3144fa69dc32273a0a21fc4e023c9931f530449096bb26c538`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

