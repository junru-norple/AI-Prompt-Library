<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 建築編輯式 Next.js 高質感網站起始套件

## 繁體中文

- Entry ID: `cinematic-web:nextjs-cinematic-starter`
- Artifact kind: `artifact-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/nextjs-cinematic-starter/index.html`
- Source SHA-256: `d0f3e4ca7e1cd5181d51c7df987860e38e9922f6e7b5649aa9c9fff366d4cbe4`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
