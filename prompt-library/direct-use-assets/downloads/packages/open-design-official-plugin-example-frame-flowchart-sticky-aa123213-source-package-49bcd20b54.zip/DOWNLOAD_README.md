<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 粘性流程圖框架（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-frame-flowchart-sticky-aa123213`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/frame-flowchart-sticky/example.html`
- 來源 SHA-256：`a93d0c971d0444ee387e0ed3d9bd009aa98786d1f17e3046f275d5ae7eb2cfca`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

