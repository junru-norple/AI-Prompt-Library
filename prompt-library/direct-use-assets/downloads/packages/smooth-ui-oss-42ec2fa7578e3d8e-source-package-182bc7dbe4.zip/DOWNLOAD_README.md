<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · SDF Circle Transition

## 繁體中文

- Entry ID: `smooth-ui-oss:42ec2fa7578e3d8e`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/sdf-circle-transition/index.tsx`
- 來源 SHA-256：`1ff0e01b02eaafcaf59fa94365af035c8609b40ec6a1c5453c006f862e93249d`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

