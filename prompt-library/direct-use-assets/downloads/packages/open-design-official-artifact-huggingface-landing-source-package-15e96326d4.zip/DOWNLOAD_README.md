<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# huggingface 設計系統成果：landing

## 繁體中文

- Entry ID: `open-design-official:artifact:huggingface:landing`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/huggingface/system/artifacts/landing.html`
- 來源 SHA-256：`13cdb903700fb086b322c8abe01bb6c5c45c10656a3e9134d3f75afcb9217e44`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

