<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像战略项目负责人一样讲运营模式重设计（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-ppt-keynote-f9609196`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/ppt-keynote/example.html`
- 來源 SHA-256：`ca456e7d152eb3afd628a97fefa0f972bde1a3175c0b0bda29c662597a58d660`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

