<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Micro Scale Fade

## 繁體中文

- Entry ID: `smooth-ui-oss:b9b3b7739cd08d20`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/micro-scale-fade/index.tsx`
- 來源 SHA-256：`9bc575f51e8c90d082d61bdcdd92ac97eebcac411ce5e663175616fa25ca8a36`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

