<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Avatar Picker

## 繁體中文

- Entry ID: `kokonut-ui-oss:1ceb675aa406e9d6`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/avatar-picker.tsx`
- 來源 SHA-256：`cd01dbf9b1fcfa4dc71f7a40c826ae4d6ba4dff9606bdec7309fc9d282a13363`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

