<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Morphic Navbar

## 繁體中文

- Entry ID: `kokonut-ui-oss:b815356bdee68bb8`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/morphic-navbar.tsx`
- 來源 SHA-256：`8359a5db873e88ee572dd43386ca155e5ee39b6bb15becd74cce02d27ab2e8fc`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

