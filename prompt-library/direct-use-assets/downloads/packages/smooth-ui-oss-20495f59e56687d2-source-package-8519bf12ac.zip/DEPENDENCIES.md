<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- @repo/shadcn-ui@workspace:*
- @repo/smooth-button@workspace:*
- @smoothui/data@workspace:*
- motion@^11.15.0
- react-dom@^19.2.0
- react@^19.2.0

The following packages are declared by the source project and are not bundled in this ZIP:
- @repo/shadcn-ui@workspace:*
- @repo/smooth-button@workspace:*
- @smoothui/data@workspace:*
- motion@^11.15.0
- react-dom@^19.2.0
- react@^19.2.0
