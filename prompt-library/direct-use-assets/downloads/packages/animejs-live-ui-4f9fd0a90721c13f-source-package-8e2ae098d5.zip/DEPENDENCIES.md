<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已封裝及排除相依 / Bundled and excluded dependencies

繁體中文：Anime.js 4.5.0 Runtime 依 MIT 封裝；完整 MIT 授權位於 LICENSES。上游 IoskeleyMono 字型未獲本專案確認授權，因此未封裝。離線 preview 使用系統字型，不需套件安裝或網路。原始來源保留既有字型宣告供來源比對，不代表字型已提供。

English: The Anime.js 4.5.0 runtime is bundled under MIT, with the full license in LICENSES. The upstream IoskeleyMono fonts are excluded because their redistribution license was not verified. The offline preview uses system fonts and needs no package installation or network. Original source retains its font declarations for source comparison; this does not mean the fonts are bundled.

## 原始來源讀取 / Original source reading

原始 HTML／CSS 保留 IoskeleyMono-Regular.woff2 與 IoskeleyMono-Bold.woff2 字型引用；再散布授權未確認，因此不封裝，Library 離線預覽使用系統字型。此範例原文還引用不存在於固定來源的 assets/css/styles.css；可用的共用樣式位於 examples/assets/css/styles.css，原始檔未擅自改寫。

The original HTML/CSS retains references to IoskeleyMono-Regular.woff2 and IoskeleyMono-Bold.woff2. They are not bundled because redistribution rights are unverified; the Library offline preview uses system fonts. This source also references assets/css/styles.css, which is absent at that relative location in the fixed source. The shared stylesheet exists at examples/assets/css/styles.css; the original file is preserved without rewriting.
