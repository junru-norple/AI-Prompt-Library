<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Spinning Text

## 繁體中文

- Entry ID: `magic-ui-oss:54700f17c18594aa`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/spinning-text.tsx`
- 來源 SHA-256：`55726f972d09705b0cd10e8739e74afe8d11b7164537554f99905267e456dafa`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

