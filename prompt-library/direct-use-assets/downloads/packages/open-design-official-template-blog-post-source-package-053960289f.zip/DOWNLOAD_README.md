<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# blog-post

## 繁體中文

- Entry ID: `open-design-official:template:blog-post`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-templates/blog-post/example.html`
- 來源 SHA-256：`3470fd24dd33bebae866109f1705bc6863ef8e7aa1a13be091e16e1bf8136244`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

