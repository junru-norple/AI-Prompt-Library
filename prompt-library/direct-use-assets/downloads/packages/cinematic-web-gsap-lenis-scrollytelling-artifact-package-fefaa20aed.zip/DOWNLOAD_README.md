<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 潮汐研究平滑捲動敘事

## 繁體中文

- Entry ID: `cinematic-web:gsap-lenis-scrollytelling`
- Artifact kind: `artifact-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/gsap-lenis-scrollytelling/index.html`
- Source SHA-256: `68141c6356b77b0a74f1a85ce6d5371cbcc355507a6aa6ee435a23c9b8ed1296`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
