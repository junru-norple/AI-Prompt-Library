<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像成长股权分析师一样写投资 Pitch Book（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-ib-pitch-book-174b5a2e`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/ib-pitch-book/assets/template.html`
- 來源 SHA-256：`63821116577b202a2f0f40f603c95ea201a614d54b68a8d42c7c0e98cad1f915`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

