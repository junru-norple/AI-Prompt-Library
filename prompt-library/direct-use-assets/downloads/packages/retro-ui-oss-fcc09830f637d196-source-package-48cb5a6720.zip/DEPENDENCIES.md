<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- https://retroui.dev/r/menu.json

The following packages are declared by the source project and are not bundled in this ZIP:
- https://retroui.dev/r/menu.json
