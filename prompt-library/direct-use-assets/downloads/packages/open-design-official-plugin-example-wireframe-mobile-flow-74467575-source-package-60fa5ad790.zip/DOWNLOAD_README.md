<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 行動端線框流程（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-wireframe-mobile-flow-74467575`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/wireframe-mobile-flow/example.html`
- 來源 SHA-256：`8ffdf6a7a2743b4056427a1ad08211e4d974ecd23ed8633561bbde5f1d877c68`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

