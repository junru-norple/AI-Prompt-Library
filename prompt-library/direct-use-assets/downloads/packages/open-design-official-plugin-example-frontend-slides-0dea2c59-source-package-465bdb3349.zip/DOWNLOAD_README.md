<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像顶级技术解释者一样写 AI 工作流 101（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-frontend-slides-0dea2c59`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/frontend-slides/example.html`
- 來源 SHA-256：`5ef0a54da244678b81a08d3e0914e6ef3001281d4ab287d0b9ead91e753047ff`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

