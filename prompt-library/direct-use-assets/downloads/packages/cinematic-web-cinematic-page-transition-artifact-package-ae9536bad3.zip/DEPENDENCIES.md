<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

## 繁體中文

以下套件只由來源專案宣告，未封裝於本 ZIP：
- motion@13.1.1
- react@19.3.0
- react-dom@19.3.0

## English

The following packages are declared by the source project and are not bundled in this ZIP:
- motion@13.1.1
- react@19.3.0
- react-dom@19.3.0
