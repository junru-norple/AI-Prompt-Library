<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Fixed-source license evidence / 固定來源授權證據

- Source: Anime.js Official Live UI Examples
- Repository: https://github.com/juliangarnier/anime
- Commit: 2c9cf8ea00329f6768c7d7902252ed977d75ce42
- Source path: references/community/animejs-live-ui/examples/timeline-seamless-loop/index.html
- 原作者 / Original creator: 上游未提供個別作者／Individual creator not supplied by upstream
- 上游貢獻者 / Upstream contributors: 上游未提供／Not supplied by upstream
- 發布者／維護者 / Publisher or maintainer: Anime.js maintainers
- Entry license: MIT
- License status: verified
- Evidence path: LICENSE.md

The bundled source remains under the upstream license above. AI Prompt Library does not relicense it or claim authorship.
隨附來源仍依上述上游授權；AI Prompt Library 不重新授權，也不主張其為本專案原創。
