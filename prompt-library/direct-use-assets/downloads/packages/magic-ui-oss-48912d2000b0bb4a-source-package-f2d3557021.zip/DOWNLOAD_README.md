<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Smooth Cursor

## 繁體中文

- Entry ID: `magic-ui-oss:48912d2000b0bb4a`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/smooth-cursor.tsx`
- 來源 SHA-256：`bbcb3812f29fe0c128066bb83f810849a6eeb951569109d5b46bcd0f16a83c0c`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

