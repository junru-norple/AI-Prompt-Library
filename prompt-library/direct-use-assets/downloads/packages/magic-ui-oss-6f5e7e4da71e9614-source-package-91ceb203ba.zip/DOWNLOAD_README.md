<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Magic Card

## 繁體中文

- Entry ID: `magic-ui-oss:6f5e7e4da71e9614`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/magic-card.tsx`
- 來源 SHA-256：`6139e78ed228ebca18ed144f4a2714a89214c2ef604f1f82bc2f61204c3f3fa3`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

