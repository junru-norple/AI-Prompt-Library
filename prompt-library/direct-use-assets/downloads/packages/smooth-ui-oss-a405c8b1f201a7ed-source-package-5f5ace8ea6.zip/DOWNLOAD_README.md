<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Book

## 繁體中文

- Entry ID: `smooth-ui-oss:a405c8b1f201a7ed`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/book/index.tsx`
- 來源 SHA-256：`c420d85103fdb6f316428303bef76d62ce4eb2191f04335cda73e6f51e9f1a27`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

