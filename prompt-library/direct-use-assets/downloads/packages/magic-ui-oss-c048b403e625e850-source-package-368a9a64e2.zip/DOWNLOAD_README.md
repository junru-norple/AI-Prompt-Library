<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Warp Background

## 繁體中文

- Entry ID: `magic-ui-oss:c048b403e625e850`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/warp-background.tsx`
- 來源 SHA-256：`ca2d664c7ca43fcf9d59a20a484be9945a1ffc4a835f8a9e6bbb039c93249a39`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

