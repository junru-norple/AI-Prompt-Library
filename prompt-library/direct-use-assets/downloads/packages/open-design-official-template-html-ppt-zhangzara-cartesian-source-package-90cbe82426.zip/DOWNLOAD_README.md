<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# html-ppt-zhangzara-cartesian

## 繁體中文

- Entry ID: `open-design-official:template:html-ppt-zhangzara-cartesian`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-templates/html-ppt-zhangzara-cartesian/example.html`
- 來源 SHA-256：`1cef1afa1f7c92932f5275d0ce2e2f3ff4ed59cc21dd2edf0bd98f4ee9661746`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

