<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Aether 按鈕與狀態

## 繁體中文

- Entry ID: `aether-css-official:buttons`
- Artifact kind: `source-package`
- 固定來源：`aether-css-official` @ `7653acfdf22d645cb67fb128feac3ac5859e9f1d`
- 來源檔案：`references/community/aether-css/aether.css`
- 來源 SHA-256：`def0646684954c61565b35307cb95e208a5b61fc60314b115ddc3890d23f5480`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

