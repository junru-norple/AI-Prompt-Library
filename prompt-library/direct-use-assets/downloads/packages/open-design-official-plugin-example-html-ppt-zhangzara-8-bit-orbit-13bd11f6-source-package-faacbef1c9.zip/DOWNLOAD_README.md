<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像热爱驱动的讲述者一样把爱好做成故事（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-zhangzara-8-bit-orbit-13bd11f6`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-zhangzara-8-bit-orbit/example.html`
- 來源 SHA-256：`3334f93d26d3f55ddeaf0f9e1b9d92f45bea24b3d892e244952b66c5b37b1849`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

