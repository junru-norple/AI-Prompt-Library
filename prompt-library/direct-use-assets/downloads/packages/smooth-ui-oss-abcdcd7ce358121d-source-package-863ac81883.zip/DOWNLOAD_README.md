<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · AI Prompt Input

## 繁體中文

- Entry ID: `smooth-ui-oss:abcdcd7ce358121d`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/ai-prompt-input/index.tsx`
- 來源 SHA-256：`ffb737a44a962eb8d474f2c15f1ccb05ca2ae8fbe372d9fcfc884f6d160cd171`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

