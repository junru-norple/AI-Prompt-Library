<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- @repo/ai-core@workspace:*
- @repo/shadcn-ui@workspace:*
- lucide-react@^0.545.0
- motion@^12.23.25
- react-dom@^19.2.0
- react@^19.2.0

The following packages are declared by the source project and are not bundled in this ZIP:
- @repo/ai-core@workspace:*
- @repo/shadcn-ui@workspace:*
- lucide-react@^0.545.0
- motion@^12.23.25
- react-dom@^19.2.0
- react@^19.2.0
