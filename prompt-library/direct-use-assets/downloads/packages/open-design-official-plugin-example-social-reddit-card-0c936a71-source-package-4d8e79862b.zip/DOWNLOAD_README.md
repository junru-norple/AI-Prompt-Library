<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Reddit 貼文卡片（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-social-reddit-card-0c936a71`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/social-reddit-card/example.html`
- 來源 SHA-256：`91d9c08d7a84f9297c2e0b303f1feee7f9741e452654a3568b0a212488e7c7fb`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

