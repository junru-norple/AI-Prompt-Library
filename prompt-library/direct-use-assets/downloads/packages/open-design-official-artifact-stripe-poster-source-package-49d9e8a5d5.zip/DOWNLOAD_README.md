<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# stripe 設計系統成果：poster

## 繁體中文

- Entry ID: `open-design-official:artifact:stripe:poster`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/stripe/system/artifacts/poster.html`
- 來源 SHA-256：`f4a0641e61036deb8675f20eda71c6c51f6586792e4b544057bc8ae59535469d`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

