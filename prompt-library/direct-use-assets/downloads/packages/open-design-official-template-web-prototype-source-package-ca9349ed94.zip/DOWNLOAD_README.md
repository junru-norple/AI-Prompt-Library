<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# web-prototype

## 繁體中文

- Entry ID: `open-design-official:template:web-prototype`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-templates/web-prototype/assets/template.html`
- 來源 SHA-256：`202bf866237b80894177ef4e67a8b020b068a0afd94222e6012338a7da280eef`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

