<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 電影片頭分段文字揭示

## 繁體中文

- Entry ID: `cinematic-web:staggered-text-reveal`
- Artifact kind: `source-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/staggered-text-reveal/index.html`
- Source SHA-256: `551c88a7dcb8e5d9748d6366ffa3d4563842892ac2ff7b73aa84c8511bd1b120`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
