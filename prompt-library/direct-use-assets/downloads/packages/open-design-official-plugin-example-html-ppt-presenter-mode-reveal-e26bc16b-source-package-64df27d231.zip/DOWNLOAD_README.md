<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像创始 DevRel 一样做现场 AI 演示（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-presenter-mode-reveal-e26bc16b`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-presenter-mode-reveal/example.html`
- 來源 SHA-256：`79f0a3ae6dfc4da133e3b6a01ddf0c5c2797215004e7567e0121a6b2dacf97b3`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

