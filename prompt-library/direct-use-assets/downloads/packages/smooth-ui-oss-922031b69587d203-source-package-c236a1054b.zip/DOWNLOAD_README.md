<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# SmoothUI · Basic Toast

## 繁體中文

- Entry ID: `smooth-ui-oss:922031b69587d203`
- Artifact kind: `source-package`
- 固定來源：`smooth-ui-oss` @ `0a4120bb41b4d85ac796c7885552de6d0a5d7308`
- 來源檔案：`references/community/smooth-ui-oss/packages/smoothui/components/basic-toast/index.tsx`
- 來源 SHA-256：`9ad29327740b1034ad1de08539ab034c9e6356adc3cb82b9c7df82ade2589cbc`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

