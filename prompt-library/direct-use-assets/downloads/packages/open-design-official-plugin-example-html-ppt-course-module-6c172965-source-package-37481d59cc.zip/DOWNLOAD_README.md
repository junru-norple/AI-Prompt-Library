<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像顶级赋能负责人一样做新人培训模块（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-html-ppt-course-module-6c172965`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/html-ppt-course-module/example.html`
- 來源 SHA-256：`acdb9bace60774de61265b7b842f0507d7d81a644d38457d9fa92cdbaa4242c6`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

