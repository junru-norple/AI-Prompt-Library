<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# lovable 設計系統成果：form

## 繁體中文

- Entry ID: `open-design-official:artifact:lovable:form`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/lovable/system/artifacts/form.html`
- 來源 SHA-256：`ace40b8ffc3c8029171651171738050b7986c9fa9e224a540ea51e67c4eb51b4`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

