<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Aether CSS 完整設計系統

## 繁體中文

- Entry ID: `aether-css-official:system`
- Artifact kind: `source-package`
- 固定來源：`aether-css-official` @ `7653acfdf22d645cb67fb128feac3ac5859e9f1d`
- 來源檔案：`references/community/aether-css/index.html`
- 來源 SHA-256：`e28c0a52f21e998aa3c27ccfd454abaa5ad8337b1ec346e06ff1bfece5a145cb`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.
## 原始來源讀取 / Original source reading

原始 HTML 的 ./icon.png favicon 不存在於固定上游來源；此原始引用如實保留。樣式、3 個 SVG 圖示與 demo.png 均附原始檔，Library 的離線預覽不依賴缺失的 favicon。

The original HTML references ./icon.png as a favicon, but that file is absent from the fixed upstream source. The original reference is preserved. Styles, the three SVG icons and demo.png are bundled; the Library offline preview does not depend on the missing favicon.

