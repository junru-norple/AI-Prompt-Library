<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

繁體中文：此來源 Artifact 沒有記錄外部依賴。

English: No external dependency is recorded for this source artifact.

## 原始來源讀取 / Original source reading

原始 HTML 的 ./icon.png favicon 不存在於固定上游來源；此原始引用如實保留。樣式、3 個 SVG 圖示與 demo.png 均附原始檔，Library 的離線預覽不依賴缺失的 favicon。

The original HTML references ./icon.png as a favicon, but that file is absent from the fixed upstream source. The original reference is preserved. Styles, the three SVG icons and demo.png are bundled; the Library offline preview does not depend on the missing favicon.
