<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# atelier-zero 設計系統成果：form

## 繁體中文

- Entry ID: `open-design-official:artifact:atelier-zero:form`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/atelier-zero/system/artifacts/form.html`
- 來源 SHA-256：`fa6c134a203431fd33bc57f7832434d6a8374ed7f4f60b2b79b86445497e5fbb`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

