<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- https://retroui.dev/r/toggle-group.json
- https://retroui.dev/r/toggle.json
- lucide-react

The following packages are declared by the source project and are not bundled in this ZIP:
- https://retroui.dev/r/toggle-group.json
- https://retroui.dev/r/toggle.json
- lucide-react
