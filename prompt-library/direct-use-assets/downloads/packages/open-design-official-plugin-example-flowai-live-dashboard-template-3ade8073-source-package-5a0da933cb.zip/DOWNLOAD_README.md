<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Flowai 即時儀表板範本（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-flowai-live-dashboard-template-3ade8073`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/flowai-live-dashboard-template/assets/template.html`
- 來源 SHA-256：`f77f734633a81df8be1afa8175f220d850ec2e65ba6f14f773cf717c274a4168`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

