<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Shimmer Button

## 繁體中文

- Entry ID: `magic-ui-oss:4d073de17527bd5f`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/shimmer-button.tsx`
- 來源 SHA-256：`c85ffda63ba086d2078a8dacffdfc25f0b106e1566362fa251888a214ee3c010`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

