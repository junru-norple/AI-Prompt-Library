<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

## 繁體中文

以下套件只由來源專案宣告，未封裝於本 ZIP：
- next@16.3.5
- react@19.3.0
- react-dom@19.3.0
- motion@13.1.1
- typescript@5.9.3

## English

The following packages are declared by the source project and are not bundled in this ZIP:
- next@16.3.5
- react@19.3.0
- react-dom@19.3.0
- motion@13.1.1
- typescript@5.9.3
