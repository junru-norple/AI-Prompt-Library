<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# NYT 風格資料圖表框架（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-frame-data-chart-nyt-a4462146`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/frame-data-chart-nyt/example.html`
- 來源 SHA-256：`8da93fda5a83209fca5371a30644fa6da2a8299763a02d55a0732c569307e650`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

