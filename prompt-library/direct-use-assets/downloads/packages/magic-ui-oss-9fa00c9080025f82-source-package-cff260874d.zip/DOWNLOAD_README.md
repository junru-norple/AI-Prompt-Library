<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Magic UI · Text Reveal

## 繁體中文

- Entry ID: `magic-ui-oss:9fa00c9080025f82`
- Artifact kind: `source-package`
- 固定來源：`magic-ui-oss` @ `0bd8b9fe0e15c4697c8d22dee1d35d88b5152c25`
- 來源檔案：`references/community/magic-ui-oss/apps/www/registry/magicui/text-reveal.tsx`
- 來源 SHA-256：`af69b435aa66a762af04d7d85b8578627ad9fb6541d01170135756e647d36240`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

