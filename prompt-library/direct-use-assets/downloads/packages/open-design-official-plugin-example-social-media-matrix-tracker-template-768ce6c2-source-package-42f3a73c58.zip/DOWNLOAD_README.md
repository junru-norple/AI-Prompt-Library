<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 社群媒體矩陣追蹤面板範本（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-social-media-matrix-tracker-template-768ce6c2`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/social-media-matrix-tracker-template/assets/template.html`
- 來源 SHA-256：`9c25635639969f08cbfef8350ac80d087c528c929122572cf7195f375738e0e1`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

