<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 潮汐研究平滑捲動敘事

## 繁體中文

- Entry ID: `cinematic-web:gsap-lenis-scrollytelling`
- Artifact kind: `source-package`
- Source: `local-original-cinematic-web`
- Source file: `references/original/cinematic-web/packages/gsap-lenis-scrollytelling/src/main.js`
- Source SHA-256: `e415b31b555cf0fcd7be6be26c0f4d45fb0e13344fcc52272b85007cf5c9979f`

此 ZIP 是對應 AI Prompt Library 項目的可攜式來源套件；Preview 與下載 Artifact 分離。原創程式碼依 MIT，原創 Prompt、README 與設計文字依 CC BY 4.0，且都僅限 junru-norple 實際持有權利的部分。

## English

This ZIP is the portable source package for the matching AI Prompt Library entry. Preview and download artifacts are separate. Original code is offered under MIT; original prompts, README copy, and design text are offered under CC BY 4.0, in each case only to the extent rights are held by junru-norple.
