<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Kokonut UI 元件：Hold Button

## 繁體中文

- Entry ID: `kokonut-ui-oss:d87b7339d19e58ff`
- Artifact kind: `source-package`
- 固定來源：`kokonut-ui-oss` @ `13f3d666c008a868ef2b9af371e6c6003fe4ee80`
- 來源檔案：`references/community/kokonut-ui-oss/components/kokonutui/hold-button.tsx`
- 來源 SHA-256：`5f33b0b6988fff823c5bff01e67cec1c457ce225f6569ee3efefaa7a26b620df`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

