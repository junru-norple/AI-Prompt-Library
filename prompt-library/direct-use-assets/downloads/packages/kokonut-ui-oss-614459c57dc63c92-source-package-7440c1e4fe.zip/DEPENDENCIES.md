<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 已宣告依賴 / Declared dependencies

以下套件只由來源專案宣告，未封裝於本 ZIP：
- react
- react-dom
- tailwindcss
- motion
- @radix-ui/react-slot
- class-variance-authority
- clsx
- tailwind-merge
- shadcn/ui:card
- shadcn/ui:button

The following packages are declared by the source project and are not bundled in this ZIP:
- react
- react-dom
- tailwindcss
- motion
- @radix-ui/react-slot
- class-variance-authority
- clsx
- tailwind-merge
- shadcn/ui:card
- shadcn/ui:button
