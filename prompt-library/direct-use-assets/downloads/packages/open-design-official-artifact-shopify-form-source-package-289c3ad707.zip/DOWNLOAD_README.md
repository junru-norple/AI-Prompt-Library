<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# shopify 設計系統成果：form

## 繁體中文

- Entry ID: `open-design-official:artifact:shopify:form`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/design-systems/shopify/system/artifacts/form.html`
- 來源 SHA-256：`4c95899a3059ac32ed8683d53d49f6b25fa450e4977542f4ffaba2b6d8dd1919`
- 上游授權：`Apache-2.0`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

