<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# WebGL 體驗（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-webgl-experience-5d798ce6`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/webgl-experience/example.html`
- 來源 SHA-256：`94a36f13ece36d6e9071d2af0274195648fb2bc1de64f0a4670d5205ba24ed2e`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

