<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# 像增长策略负责人一样写品牌发布叙事（產出模板套件）

## 繁體中文

- Entry ID: `open-design-official:plugin:example-fs-emerald-editorial-0b32f268`
- Artifact kind: `source-package`
- 固定來源：`open-design-official` @ `bf714528070d5cf1cfcdd25bdc7c9efc7e129d0b`
- 來源檔案：`references/community/open-design/plugins/_official/examples/fs-emerald-editorial/example.html`
- 來源 SHA-256：`0af70e4d6c28366cf62ed7ffae240d599c6fc03254e4ee34a52a76960e5af9a1`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.

