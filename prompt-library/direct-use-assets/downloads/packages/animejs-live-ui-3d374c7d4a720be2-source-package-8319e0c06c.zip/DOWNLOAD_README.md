<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Anime.js 動畫：Auto layout / Todo list

## 繁體中文

- Entry ID: `animejs-live-ui:3d374c7d4a720be2`
- Artifact kind: `source-package`
- 固定來源：`animejs-live-ui` @ `2c9cf8ea00329f6768c7d7902252ed977d75ce42`
- 來源檔案：`references/community/animejs-live-ui/examples/auto-layout/todo-list/index.html`
- 來源 SHA-256：`01105e6a348ff82bc3216702b1b3cd62bce186f1b225b1bbabc863f087d0c28e`
- 上游授權：`MIT`

此 ZIP 僅將固定版本的上游來源包裝為可攜下載；Preview 與 Download 分離。來源權利與授權均維持上游範圍，本專案不主張原創或重新授權。

## English

This ZIP is a portable package of fixed-version upstream source. Preview and Download remain separate. Upstream ownership and license scope are preserved; this project claims neither authorship nor relicensing.
## 原始來源讀取 / Original source reading

原始 HTML／CSS 保留 IoskeleyMono-Regular.woff2 與 IoskeleyMono-Bold.woff2 字型引用；再散布授權未確認，因此不封裝，Library 離線預覽使用系統字型。

The original HTML/CSS retains references to IoskeleyMono-Regular.woff2 and IoskeleyMono-Bold.woff2. They are not bundled because redistribution rights are unverified; the Library offline preview uses system fonts.


## 離線範例 / Offline example

解壓後開啟 `preview/index.html`，即可使用與 Library 相同、固定來源改作的離線範例；Anime.js MIT Runtime 已內嵌。`source/` 保留此項目的原始 HTML／JavaScript、共用 CSS 與 ES module runtime。原始 ES module 範例需要相容的本機 HTTP 開發環境；不要以原始 HTML 的 file:// 行為推定它可直接執行。未取得授權的上游字型不封裝，離線範例改用系統字型。

After extracting, open `preview/index.html` for the same fixed-source offline adaptation shown in the Library, with the MIT Anime.js runtime embedded. `source/` preserves this example's original HTML/JavaScript, shared CSS, and ES module runtime. The original module example requires a compatible local HTTP development environment; its raw file:// behavior is not a runnable-preview claim. Unverified upstream fonts are excluded; the offline adaptation uses system fonts.
